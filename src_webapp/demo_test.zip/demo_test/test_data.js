'use strict';


var arr = [
  // 
  {
    id: 1,
    name: 'admin'
  },
];

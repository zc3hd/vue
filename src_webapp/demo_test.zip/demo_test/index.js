function Nav () {
	
}
Nav.prototype={
	init:function () {
		console.log(1);

		$('#point_box').css('transform','rotate(1deg)')
		var index = 1;
		var timer = setInterval(function () {
			index+=1;
			$('#point_box').css('transform',`rotate(${index}deg)`);
			if (index==180) {
				clearInterval(timer)
			}
		},16);
	},
};